const { Plugin, Notice } = require("obsidian");
const http = require("http");

const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};
const DIRTY_WORKSPACE_TAG = "#workspace/dirty";
const RUNTIME_DIRTY_GRAPH_COLORS = true;
const SOURCE_GRAPH_PREFIX = "Kloel/99 - Espelho do Codigo/_source/";
const WORKSPACE_GRAPH_SEARCH = "";
const WORKSPACE_GRAPH_COLOR_GROUPS = [
  { query: "tag:#workspace/dirty", color: { a: 1, rgb: 14724096 } },
  { query: "tag:#graph/action-required", color: { a: 1, rgb: 16711680 } },
  { query: "tag:#graph/evidence-gap", color: { a: 1, rgb: 16711935 } },
  { query: "tag:#graph/effect-security", color: { a: 1, rgb: 10040524 } },
  { query: "tag:#graph/effect-error", color: { a: 1, rgb: 16724736 } },
  { query: "tag:#graph/effect-entrypoint", color: { a: 1, rgb: 65280 } },
  { query: "tag:#graph/effect-data", color: { a: 1, rgb: 255 } },
  { query: "tag:#graph/effect-network", color: { a: 1, rgb: 65535 } },
  { query: "tag:#graph/effect-async", color: { a: 1, rgb: 5635925 } },
  { query: "tag:#graph/effect-state", color: { a: 1, rgb: 13789470 } },
  { query: "tag:#graph/effect-contract", color: { a: 1, rgb: 12632256 } },
  { query: "tag:#graph/effect-config", color: { a: 1, rgb: 11184810 } },
  { query: "tag:#mirror/metadata-only", color: { a: 1, rgb: 8421504 } },
  { query: "tag:#source/pulse-machine", color: { a: 1, rgb: 10040524 } },
  { query: "tag:#signal/static-high", color: { a: 1, rgb: 16711680 } },
  { query: "tag:#signal/hotspot", color: { a: 1, rgb: 16744192 } },
  { query: "tag:#signal/external", color: { a: 1, rgb: 65535 } },
  { query: "tag:#graph/risk-critical", color: { a: 1, rgb: 16711680 } },
  { query: "tag:#graph/risk-high", color: { a: 1, rgb: 16744192 } },
  { query: "tag:#graph/proof-test", color: { a: 1, rgb: 65280 } },
  { query: "tag:#graph/runtime-api", color: { a: 1, rgb: 65535 } },
  { query: "tag:#graph/surface-ui", color: { a: 1, rgb: 255 } },
  { query: "tag:#graph/surface-backend", color: { a: 1, rgb: 6737151 } },
  { query: "tag:#graph/surface-worker", color: { a: 1, rgb: 5635925 } },
  { query: "tag:#graph/surface-source", color: { a: 1, rgb: 11184810 } },
  { query: "tag:#graph/governance", color: { a: 1, rgb: 10040524 } },
  { query: "tag:#graph/orphan", color: { a: 1, rgb: 16711935 } },
  { query: "tag:#graph/molecule", color: { a: 1, rgb: 12632256 } },
];
const WORKSPACE_GRAPH_STATE = {
  search: WORKSPACE_GRAPH_SEARCH,
  showOrphans: true,
  hideUnresolved: true,
  colorGroups: WORKSPACE_GRAPH_COLOR_GROUPS,
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.setEncoding("utf8");
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1024 * 1024) {
        reject(new Error("Request body too large"));
        req.destroy();
      }
    });
    req.on("end", () => {
      if (!body.trim()) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(body));
      } catch (error) {
        reject(error);
      }
    });
    req.on("error", reject);
  });
}

function sendJson(res, statusCode, payload) {
  res.writeHead(statusCode, JSON_HEADERS);
  res.end(JSON.stringify(payload, null, 2));
}

function activeLeafInfo(app) {
  const leaf = app.workspace.getActiveViewOfType
    ? app.workspace.activeLeaf
    : null;
  const view = leaf && leaf.view;
  return {
    leafId: leaf && leaf.id,
    viewType: view && view.getViewType ? view.getViewType() : null,
    displayText: view && view.getDisplayText ? view.getDisplayText() : null,
    icon: view && view.getIcon ? view.getIcon() : null,
  };
}

function workspaceLeaves(app) {
  const leaves = [];
  app.workspace.iterateAllLeaves((leaf) => {
    const view = leaf.view;
    leaves.push({
      id: leaf.id,
      viewType: view && view.getViewType ? view.getViewType() : null,
      displayText: view && view.getDisplayText ? view.getDisplayText() : null,
      icon: view && view.getIcon ? view.getIcon() : null,
      active: app.workspace.activeLeaf === leaf,
    });
  });
  return leaves;
}

function domSnapshot() {
  const activeLeaf = document.querySelector(".workspace-leaf.mod-active");
  const canvases = Array.from(document.querySelectorAll("canvas")).map((canvas, index) => {
    const rect = canvas.getBoundingClientRect();
    return {
      index,
      width: canvas.width,
      height: canvas.height,
      clientWidth: canvas.clientWidth,
      clientHeight: canvas.clientHeight,
      rect: {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        left: rect.left,
        top: rect.top,
        right: rect.right,
        bottom: rect.bottom,
      },
      className: canvas.className || "",
    };
  });
  const graphContainers = Array.from(
    document.querySelectorAll(".graph-view, .workspace-leaf-content[data-type='graph'], .view-content")
  ).map((el, index) => {
    const rect = el.getBoundingClientRect();
    return {
      index,
      tag: el.tagName,
      className: el.className || "",
      dataType: el.getAttribute("data-type"),
      text: (el.innerText || "").slice(0, 500),
      rect: {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        left: rect.left,
        top: rect.top,
        right: rect.right,
        bottom: rect.bottom,
      },
    };
  });
  const activeRect = activeLeaf ? activeLeaf.getBoundingClientRect() : null;
  return {
    title: document.title,
    url: location.href,
    viewport: {
      width: window.innerWidth,
      height: window.innerHeight,
      devicePixelRatio: window.devicePixelRatio,
    },
    activeLeaf: activeRect
      ? {
          className: activeLeaf.className || "",
          rect: {
            x: activeRect.x,
            y: activeRect.y,
            width: activeRect.width,
            height: activeRect.height,
            left: activeRect.left,
            top: activeRect.top,
            right: activeRect.right,
            bottom: activeRect.bottom,
          },
        }
      : null,
    canvases,
    graphContainers,
  };
}

function dispatchMouse(type, x, y, extra = {}) {
  const target = document.elementFromPoint(x, y) || document.body;
  const event = new MouseEvent(type, {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX: x,
    clientY: y,
    screenX: window.screenX + x,
    screenY: window.screenY + y,
    button: extra.button || 0,
    buttons: extra.buttons || (type === "mouseup" ? 0 : 1),
    ctrlKey: !!extra.ctrlKey,
    metaKey: !!extra.metaKey,
    altKey: !!extra.altKey,
    shiftKey: !!extra.shiftKey,
  });
  target.dispatchEvent(event);
  return {
    type,
    x,
    y,
    target: {
      tag: target.tagName,
      className: target.className || "",
      id: target.id || "",
    },
  };
}

function dispatchWheel(x, y, deltaY, extra = {}) {
  const target = document.elementFromPoint(x, y) || document.body;
  const event = new WheelEvent("wheel", {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX: x,
    clientY: y,
    deltaY,
    deltaX: extra.deltaX || 0,
    deltaMode: 0,
    ctrlKey: !!extra.ctrlKey,
    metaKey: !!extra.metaKey,
    altKey: !!extra.altKey,
    shiftKey: !!extra.shiftKey,
  });
  target.dispatchEvent(event);
  return {
    x,
    y,
    deltaY,
    target: {
      tag: target.tagName,
      className: target.className || "",
      id: target.id || "",
    },
  };
}

function canvasDataUrl(index = 0) {
  const canvas = document.querySelectorAll("canvas")[index];
  if (!canvas) {
    return null;
  }
  return {
    index,
    width: canvas.width,
    height: canvas.height,
    dataUrl: canvas.toDataURL("image/png"),
  };
}

function fileHasDirtyWorkspaceTag(app, file) {
  const cache = app.metadataCache.getFileCache(file);
  if (!cache) {
    return false;
  }
  const inlineTags = Array.isArray(cache.tags) ? cache.tags.map((tag) => tag.tag) : [];
  const frontmatterTags = Array.isArray(cache.frontmatter && cache.frontmatter.tags)
    ? cache.frontmatter.tags.map((tag) => `#${String(tag).replace(/^#/, "")}`)
    : [];
  return inlineTags.includes(DIRTY_WORKSPACE_TAG) || frontmatterTags.includes(DIRTY_WORKSPACE_TAG);
}

function dirtyWorkspaceFiles(app) {
  return new Set(
    app.vault
      .getMarkdownFiles()
      .filter((file) => fileHasDirtyWorkspaceTag(app, file))
      .map((file) => file.path)
  );
}

async function metadataLinkStatus(app, samplePath = "") {
  const resolvedLinks = app.metadataCache.resolvedLinks || {};
  const unresolvedLinks = app.metadataCache.unresolvedLinks || {};
  const markdownFiles = app.vault.getMarkdownFiles();
  let resolvedLinkCount = 0;
  let unresolvedLinkCount = 0;
  let linkedFiles = 0;
  for (const [source, targets] of Object.entries(resolvedLinks)) {
    const count = Object.values(targets || {}).reduce((sum, value) => sum + Number(value || 0), 0);
    if (count > 0) linkedFiles += 1;
    resolvedLinkCount += count;
  }
  for (const targets of Object.values(unresolvedLinks)) {
    unresolvedLinkCount += Object.values(targets || {}).reduce(
      (sum, value) => sum + Number(value || 0),
      0
    );
  }
  const sampleFile = samplePath ? app.vault.getAbstractFileByPath(samplePath) : null;
  const sampleCache = sampleFile ? app.metadataCache.getFileCache(sampleFile) : null;
  const sampleText = sampleFile ? await app.vault.read(sampleFile) : "";
  const sampleDiskLinks = [...sampleText.matchAll(/\[\[([^\]|]+)(?:\|[^\]]+)?\]\]/g)]
    .slice(0, 20)
    .map((match) => match[1]);
  const sample = samplePath
    ? {
        path: samplePath,
        fileFound: Boolean(sampleFile),
        cacheFound: Boolean(sampleCache),
        diskLinks: sampleDiskLinks,
        cacheLinks: sampleCache?.links || [],
        cacheFrontmatterLinks: sampleCache?.frontmatterLinks || [],
        resolved: resolvedLinks[samplePath] || {},
        unresolved: unresolvedLinks[samplePath] || {},
      }
    : null;
  return {
    markdownFiles: markdownFiles.length,
    resolvedSourceFiles: Object.keys(resolvedLinks).length,
    linkedFiles,
    resolvedLinkCount,
    unresolvedLinkCount,
    sample,
  };
}

async function reindexMarkdownPrefix(app, prefix) {
  const files = app.vault
    .getMarkdownFiles()
    .filter((file) => !prefix || file.path.startsWith(prefix));
  let touched = 0;
  for (const file of files) {
    const content = await app.vault.read(file);
    await app.vault.modify(file, content);
    touched += 1;
    if (touched % 100 === 0) {
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
  }
  return { prefix, touched };
}

function updateDirtyWorkspaceFile(app, dirtyFiles, file) {
  if (!file || file.extension !== "md") {
    return false;
  }
  const wasDirty = dirtyFiles.has(file.path);
  const isDirty = fileHasDirtyWorkspaceTag(app, file);
  if (isDirty) {
    dirtyFiles.add(file.path);
  } else {
    dirtyFiles.delete(file.path);
  }
  return wasDirty !== isDirty;
}

function graphRendererStats(renderer) {
  if (!renderer) {
    return null;
  }
  return {
    nodeCount: Array.isArray(renderer.nodes)
      ? renderer.nodes.length
      : renderer.nodes && typeof renderer.nodes.size === "number"
        ? renderer.nodes.size
        : renderer.nodeLookup
          ? Object.keys(renderer.nodeLookup).length
          : null,
    linkCount: Array.isArray(renderer.links)
      ? renderer.links.length
      : renderer.links && typeof renderer.links.size === "number"
        ? renderer.links.size
        : null,
    renderTimer: !!renderer.renderTimer,
    worker: !!renderer.worker,
    idleFrames: renderer.idleFrames ?? null,
    quiescedAt: renderer.__codexQuiescedAt || null,
  };
}

function graphStatus(app) {
  const graphLeaves = [];
  app.workspace.iterateAllLeaves((leaf) => {
    if (!leaf.view || !leaf.view.getViewType || leaf.view.getViewType() !== "graph") {
      return;
    }
    graphLeaves.push({
      id: leaf.id,
      active: app.workspace.activeLeaf === leaf,
      stats: graphRendererStats(leaf.view.renderer),
    });
  });
  return { graphLeaves };
}

module.exports = class CodexObsidianBridge extends Plugin {
  async onload() {
    const saved = await this.loadData();
    this.settings = Object.assign(
      {
        host: "127.0.0.1",
        port: 37779,
        token: "",
      },
      saved || {}
    );
    this.dirtyFiles = new Set();
    this.lastDirtyGraphStatus = {
      skipped: !RUNTIME_DIRTY_GRAPH_COLORS,
      reason: RUNTIME_DIRTY_GRAPH_COLORS ? "ok" : "native-obsidian-color-groups",
      dirtyFiles: 0,
      colored: 0,
      cleared: 0,
      graphLeaves: [],
    };
    this.scheduleDirtyGraphRefresh = (forceFullScan = false) => {
      if (!RUNTIME_DIRTY_GRAPH_COLORS) {
        this.lastDirtyGraphStatus = {
          skipped: true,
          reason: "native-obsidian-color-groups",
          dirtyFiles: this.dirtyFiles.size,
          colored: 0,
          cleared: 0,
          graphLeaves: [],
        };
        return;
      }

      if (forceFullScan) {
        this.dirtyFiles = dirtyWorkspaceFiles(this.app);
      }

      this.lastDirtyGraphStatus = {
        skipped: false,
        reason: null,
        dirtyFiles: this.dirtyFiles.size,
        colored: 0,
        cleared: 0,
        graphLeaves: graphStatus(this.app).graphLeaves,
      };
    };
    await this.startServer();
    this.registerEvent(
      this.app.metadataCache.on("changed", (file) => {
        if (updateDirtyWorkspaceFile(this.app, this.dirtyFiles, file)) {
          this.scheduleDirtyGraphRefresh(false);
        }
      })
    );
    this.registerEvent(
      this.app.metadataCache.on("deleted", (file) => {
        if (file && this.dirtyFiles.delete(file.path)) {
          this.scheduleDirtyGraphRefresh(false);
        }
      })
    );
    this.registerEvent(
      this.app.metadataCache.on("resolved", () => {
        this.scheduleDirtyGraphRefresh(true);
      })
    );
    this.registerEvent(
      this.app.workspace.on("layout-change", () => {
        this.scheduleDirtyGraphRefresh(false);
      })
    );
    this.scheduleDirtyGraphRefresh(true);
    this.addCommand({
      id: "bridge-status",
      name: "Show Codex bridge status",
      callback: () => new Notice(`Codex bridge listening on ${this.settings.host}:${this.settings.port}`),
    });
  }

  onunload() {
    if (this.server) {
      this.server.close();
      this.server = null;
    }
  }

  async startServer() {
    this.server = http.createServer(async (req, res) => {
      if (req.socket.remoteAddress !== "127.0.0.1" && req.socket.remoteAddress !== "::1") {
        sendJson(res, 403, { ok: false, error: "Only localhost is allowed" });
        return;
      }
      if (this.settings.token && req.headers["x-codex-token"] !== this.settings.token) {
        sendJson(res, 401, { ok: false, error: "Missing or invalid x-codex-token" });
        return;
      }

      try {
        const url = new URL(req.url, `http://${req.headers.host}`);
        if (req.method === "GET" && url.pathname === "/status") {
          sendJson(res, 200, {
            ok: true,
            vaultName: this.app.vault.getName(),
            activeLeaf: activeLeafInfo(this.app),
            leaves: workspaceLeaves(this.app),
            commandCount: Object.keys(this.app.commands.commands).length,
          });
          return;
        }

        if (req.method === "GET" && url.pathname === "/commands") {
          const q = (url.searchParams.get("q") || "").toLowerCase();
          const commands = Object.values(this.app.commands.commands)
            .filter((command) => !q || `${command.id} ${command.name}`.toLowerCase().includes(q))
            .map((command) => ({ id: command.id, name: command.name }))
            .sort((a, b) => a.id.localeCompare(b.id));
          sendJson(res, 200, { ok: true, commands });
          return;
        }

        if (req.method === "POST" && url.pathname === "/command") {
          const body = await readBody(req);
          if (!body.id) {
            sendJson(res, 400, { ok: false, error: "Missing command id" });
            return;
          }
          const result = this.app.commands.executeCommandById(body.id);
          sendJson(res, 200, { ok: true, id: body.id, result });
          return;
        }

        if (req.method === "POST" && url.pathname === "/open-graph") {
          const body = await readBody(req);
          const leaf = this.app.workspace.getLeaf(true);
          await leaf.setViewState({
            type: "graph",
            state: body.state && typeof body.state === "object" ? body.state : WORKSPACE_GRAPH_STATE,
            active: true,
          });
          this.app.workspace.setActiveLeaf(leaf, { focus: true });
          sendJson(res, 200, { ok: true, activeLeaf: activeLeafInfo(this.app), graph: graphStatus(this.app), dom: domSnapshot() });
          return;
        }

        if (req.method === "GET" && url.pathname === "/graph-status") {
          sendJson(res, 200, { ok: true, status: graphStatus(this.app) });
          return;
        }

        if (req.method === "GET" && url.pathname === "/metadata-link-status") {
          sendJson(res, 200, {
            ok: true,
            status: await metadataLinkStatus(this.app, url.searchParams.get("sample") || ""),
          });
          return;
        }

        if (req.method === "POST" && url.pathname === "/reindex-markdown-prefix") {
          const body = await readBody(req);
          const result = await reindexMarkdownPrefix(this.app, body.prefix || "");
          sendJson(res, 200, { ok: true, result });
          return;
        }

        if (req.method === "POST" && url.pathname === "/quiesce-graph") {
          sendJson(res, 409, {
            ok: false,
            error: "Graph renderer control is disabled. Obsidian native rendering owns the graph.",
            status: graphStatus(this.app),
          });
          return;
        }

        if (req.method === "POST" && url.pathname === "/thaw-graph") {
          sendJson(res, 200, { ok: true, status: graphStatus(this.app) });
          return;
        }

        if (req.method === "GET" && url.pathname === "/dom") {
          sendJson(res, 200, { ok: true, dom: domSnapshot() });
          return;
        }

        if (req.method === "GET" && url.pathname === "/dirty-graph-status") {
          this.lastDirtyGraphStatus = {
            skipped: true,
            reason: "native-obsidian-color-groups",
            dirtyFiles: this.dirtyFiles.size,
            colored: 0,
            cleared: 0,
            graphLeaves: [],
          };
          sendJson(res, 200, { ok: true, status: this.lastDirtyGraphStatus });
          return;
        }

        if (req.method === "GET" && url.pathname === "/canvas") {
          const index = Number(url.searchParams.get("index") || "0");
          sendJson(res, 200, { ok: true, canvas: canvasDataUrl(index) });
          return;
        }

        if (req.method === "POST" && url.pathname === "/click") {
          const body = await readBody(req);
          const x = Number(body.x);
          const y = Number(body.y);
          dispatchMouse("mousemove", x, y, body);
          dispatchMouse("mousedown", x, y, body);
          dispatchMouse("mouseup", x, y, body);
          const click = dispatchMouse("click", x, y, body);
          sendJson(res, 200, { ok: true, click, dom: domSnapshot() });
          return;
        }

        if (req.method === "POST" && url.pathname === "/drag") {
          const body = await readBody(req);
          const from = body.from || {};
          const to = body.to || {};
          const steps = Math.max(2, Math.min(80, Number(body.steps || 20)));
          const events = [];
          events.push(dispatchMouse("mousemove", Number(from.x), Number(from.y), body));
          events.push(dispatchMouse("mousedown", Number(from.x), Number(from.y), body));
          for (let step = 1; step <= steps; step += 1) {
            const t = step / steps;
            const x = Number(from.x) + (Number(to.x) - Number(from.x)) * t;
            const y = Number(from.y) + (Number(to.y) - Number(from.y)) * t;
            events.push(dispatchMouse("mousemove", x, y, body));
          }
          events.push(dispatchMouse("mouseup", Number(to.x), Number(to.y), body));
          sendJson(res, 200, { ok: true, events, dom: domSnapshot() });
          return;
        }

        if (req.method === "POST" && url.pathname === "/wheel") {
          const body = await readBody(req);
          const wheel = dispatchWheel(Number(body.x), Number(body.y), Number(body.deltaY), body);
          sendJson(res, 200, { ok: true, wheel, dom: domSnapshot() });
          return;
        }

        sendJson(res, 404, { ok: false, error: "Not found" });
      } catch (error) {
        sendJson(res, 500, { ok: false, error: error.message, stack: error.stack });
      }
    });

    await new Promise((resolve, reject) => {
      this.server.once("error", reject);
      this.server.listen(this.settings.port, this.settings.host, resolve);
    });
    console.log(`[codex-obsidian-bridge] listening on ${this.settings.host}:${this.settings.port}`);
  }
};
