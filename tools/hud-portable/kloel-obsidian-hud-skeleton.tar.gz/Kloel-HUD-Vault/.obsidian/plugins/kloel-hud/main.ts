import {
  Plugin,
  PluginSettingTab,
  Setting,
  ItemView,
  WorkspaceLeaf,
} from "obsidian";
import { readFileSync, existsSync, watchFile } from "node:fs";
import { resolve } from "node:path";

interface BlockerEntry {
  file: string;
  score: number;
  tier: string;
  phase: string;
  severityCounts?: {
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
}

interface BlockerRankData {
  topN: BlockerEntry[];
  generatedAt: string;
  totalBlockers: number;
}

interface KloelHudSettings {
  blockerRankPath: string;
  refreshIntervalSec: number;
  lastRefreshPath: string;
}

const DEFAULT_SETTINGS: KloelHudSettings = {
  blockerRankPath: "__KLOEL_REPO_ROOT__/BLOCKER_RANK.json",
  refreshIntervalSec: 60,
  lastRefreshPath: "__KLOEL_REPO_ROOT__/HUD_LAST_REFRESH.json",
};

export default class KloelHudPlugin extends Plugin {
  settings!: KloelHudSettings;
  statusBarItem!: HTMLElement;
  refreshTimer: number | null = null;
  fileWatcher: ReturnType<typeof watchFile> | null = null;

  async onload() {
    await this.loadSettings();

    this.statusBarItem = this.addStatusBarItem();
    this.statusBarItem.addClass("kloel-hud-status");

    this.addCommand({
      id: "open-next",
      name: "KLOEL: Open 00-NEXT",
      hotkeys: [{ modifiers: ["Mod", "Shift"], key: "n" }],
      callback: () => {
        const file = this.app.vault.getAbstractFileByPath(
          "Kloel/00-HUD/00-NEXT.md"
        );
        if (file) {
          this.app.workspace.getLeaf().openFile(file as any);
        }
      },
    });

    this.addCommand({
      id: "open-blockers",
      name: "KLOEL: Open 00-BLOCKERS",
      hotkeys: [{ modifiers: ["Mod", "Shift"], key: "b" }],
      callback: () => {
        const file = this.app.vault.getAbstractFileByPath(
          "Kloel/00-HUD/00-BLOCKERS.md"
        );
        if (file) {
          this.app.workspace.getLeaf().openFile(file as any);
        }
      },
    });

    this.registerView(
      "kloel-oracle",
      (leaf) => new OracleView(leaf, this)
    );

    this.addRibbonIcon("target", "KLOEL Oracle", () =>
      this.activateOracleView()
    );

    this.addSettingTab(new KloelHudSettingTab(this.app, this));

    this.refreshStatus();
    this.startPolling();
    this.startFileWatcher();
  }

  startPolling() {
    this.refreshTimer = window.setInterval(
      () => this.refreshStatus(),
      this.settings.refreshIntervalSec * 1000
    );
    this.registerInterval(this.refreshTimer);
  }

  startFileWatcher() {
    try {
      const watchPath = this.settings.lastRefreshPath;
      if (existsSync(watchPath)) {
        this.fileWatcher = watchFile(watchPath, () => {
          this.refreshStatus();
        });
        this.register(() => {
          if (this.fileWatcher) {
            (this.fileWatcher as any).unref?.();
          }
        });
      }
    } catch {
      // fs.watchFile not available or path missing; fall back to polling only
    }
  }

  readBlockerRank(): BlockerRankData | null {
    try {
      const path = this.settings.blockerRankPath;
      if (!existsSync(path)) return null;
      const raw = readFileSync(path, "utf8");
      return JSON.parse(raw) as BlockerRankData;
    } catch {
      return null;
    }
  }

  refreshStatus() {
    const data = this.readBlockerRank();
    if (!data || !data.topN) {
      this.statusBarItem.setText("\u{1F6A8} KLOEL: no rank yet");
      return;
    }

    const counts = { critical: 0, high: 0, medium: 0, low: 0 };
    let topPhase = "";
    let topPhaseScore = 0;

    for (const entry of data.topN) {
      if (entry.severityCounts) {
        counts.critical += entry.severityCounts.critical || 0;
        counts.high += entry.severityCounts.high || 0;
        counts.medium += entry.severityCounts.medium || 0;
        counts.low += entry.severityCounts.low || 0;
      }
      if (entry.score > topPhaseScore) {
        topPhaseScore = entry.score;
        topPhase = entry.phase || "";
      }
    }

    const total =
      counts.critical + counts.high + counts.medium + counts.low;
    const donePct =
      total > 0
        ? Math.round(
            ((data.totalBlockers - total) / data.totalBlockers) * 100
          )
        : 0;

    const faseLabel = topPhase ? `FASE ${topPhase}` : "";
    const pctLabel = `${donePct}%`;

    if (faseLabel) {
      this.statusBarItem.setText(
        `\u{1F6A8} ${counts.critical}c/${counts.high}h \u2022 ${faseLabel} ${pctLabel}`
      );
    } else {
      this.statusBarItem.setText(
        `\u{1F6A8} ${counts.critical}c/${counts.high}h \u2022 ${pctLabel}`
      );
    }

    this.app.workspace.trigger("kloel-hud:refresh");
  }

  async activateOracleView() {
    const { workspace } = this.app;

    const leaves = workspace.getLeavesOfType("kloel-oracle");
    if (leaves.length > 0) {
      workspace.revealLeaf(leaves[0]);
      return;
    }

    const leaf = workspace.getRightLeaf(false);
    if (leaf) {
      await leaf.setViewState({ type: "kloel-oracle", active: true });
      workspace.revealLeaf(leaf);
    }
  }

  async loadSettings() {
    this.settings = Object.assign(
      {},
      DEFAULT_SETTINGS,
      await this.loadData()
    );
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  onunload() {
    this.fileWatcher = null;
  }
}

class OracleView extends ItemView {
  plugin: KloelHudPlugin;

  constructor(leaf: WorkspaceLeaf, plugin: KloelHudPlugin) {
    super(leaf);
    this.plugin = plugin;
  }

  getViewType(): string {
    return "kloel-oracle";
  }

  getDisplayText(): string {
    return "KLOEL Oracle";
  }

  getIcon(): string {
    return "target";
  }

  async onOpen() {
    const container = this.containerEl.children[1] as HTMLElement;
    container.empty();
    container.addClass("kloel-oracle-view");

    this.renderContent(container);

    this.registerEvent(
      this.app.workspace.on(
        "kloel-hud:refresh" as any,
        () => {
          container.empty();
          this.renderContent(container);
        }
      )
    );
  }

  renderContent(container: HTMLElement) {
    container.createEl("h4", { text: "KLOEL Next Move" });

    const data = this.plugin.readBlockerRank();

    if (!data || !data.topN || data.topN.length === 0) {
      container.createEl("p", {
        text: "BLOCKER_RANK.json missing — run `npm run hud:once`",
        cls: "kloel-oracle-empty",
      });
      return;
    }

    const top3 = data.topN.slice(0, 3);
    const list = container.createEl("ol");

    for (const entry of top3) {
      const li = list.createEl("li");
      li.createEl("strong", { text: entry.file });
      li.createEl("br");

      const sev = entry.severityCounts;
      const sevParts: string[] = [];
      if (sev) {
        if (sev.critical) sevParts.push(`${sev.critical} crit`);
        if (sev.high) sevParts.push(`${sev.high} high`);
        if (sev.medium) sevParts.push(`${sev.medium} med`);
        if (sev.low) sevParts.push(`${sev.low} low`);
      }
      const sevStr = sevParts.length > 0 ? ` [${sevParts.join(", ")}]` : "";

      li.createEl("small", {
        text: `score=${entry.score.toFixed(2)} tier=${entry.tier} phase=${entry.phase}${sevStr}`,
      });
    }

    const footer = container.createEl("p", {
      cls: "kloel-oracle-empty",
    });
    footer.createEl("small", {
      text: `Generated: ${data.generatedAt || "unknown"}  |  Total blockers: ${data.totalBlockers}`,
    });
  }

  async onClose() {
    // cleanup handled by Obsidian
  }
}

class KloelHudSettingTab extends PluginSettingTab {
  plugin: KloelHudPlugin;

  constructor(app: any, plugin: KloelHudPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;
    containerEl.empty();

    containerEl.createEl("h2", { text: "KLOEL HUD Settings" });

    new Setting(containerEl)
      .setName("BLOCKER_RANK.json path")
      .setDesc("Absolute path to the BLOCKER_RANK.json file")
      .addText((text) =>
        text
          .setValue(this.plugin.settings.blockerRankPath)
          .onChange(async (value) => {
            this.plugin.settings.blockerRankPath = value;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("HUD_LAST_REFRESH.json path")
      .setDesc("Absolute path to the HUD_LAST_REFRESH.json file (polled for change detection)")
      .addText((text) =>
        text
          .setValue(this.plugin.settings.lastRefreshPath)
          .onChange(async (value) => {
            this.plugin.settings.lastRefreshPath = value;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Refresh interval (seconds)")
      .setDesc("How often to re-read BLOCKER_RANK.json (poll-based)")
      .addText((text) =>
        text
          .setValue(String(this.plugin.settings.refreshIntervalSec))
          .onChange(async (value) => {
            this.plugin.settings.refreshIntervalSec = Number(value) || 60;
            await this.plugin.saveSettings();
          })
      );
  }
}
