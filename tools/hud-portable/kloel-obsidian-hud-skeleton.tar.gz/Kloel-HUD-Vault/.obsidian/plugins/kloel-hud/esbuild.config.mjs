import esbuild from "esbuild";
import process from "node:process";

const prod = process.argv[2] === "production";

const ctx = await esbuild.build({
  entryPoints: ["main.ts"],
  bundle: true,
  platform: "node",
  target: "node18",
  external: ["obsidian", "electron", "@electron/remote"],
  format: "cjs",
  outfile: "main.js",
  sourcemap: prod ? false : "inline",
  minify: prod,
  treeShaking: true,
  logLevel: "info",
});

if (!prod) {
  await ctx.rebuild?.();
  const chokidar = await import("chokidar").catch(() => null);
  if (chokidar) {
    console.log("watching for changes...");
  }
} else {
  console.log("build complete");
}
