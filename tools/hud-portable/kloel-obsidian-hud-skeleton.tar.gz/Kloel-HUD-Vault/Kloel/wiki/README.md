---
tags:
  - meta/instructions
auto_generated: false
purpose: wiki folder explanation
---

# wiki/ — LLM-synthesized concepts

LLM-synthesized notes that compile knowledge from `raw/` sources.

**Subfolders**:
- `concepts/` — abstract topics (e.g. "Stripe Connect onboarding flow")
- `entities/` — concrete things (e.g. "FraudEngine", "SplitEngine")
- `decisions/` — why we chose X over Y (links back to ADRs in repo)

**Lifecycle**:
- **Mutable** — agents update them as understanding evolves.
- **Linked** to one or more `raw/sources/` for provenance.
- **Linted** via `/lint-vault` — finds broken links, orphan pages, contradictions.

Each note's frontmatter MUST include:
```yaml
sources:
  - "[[raw/sources/...]]"
provenance: extracted | inferred | ambiguous
```

Karpathy pattern: every claim is tagged with provenance.
