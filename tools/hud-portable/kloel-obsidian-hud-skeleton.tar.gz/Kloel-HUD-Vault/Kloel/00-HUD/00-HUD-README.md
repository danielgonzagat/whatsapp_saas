---
tags: [hud/hub, meta/instructions]
auto_generated: true
generated_at: 2026-05-06T00:18:38.773Z
purpose: "Operator guide for the KLOEL HUD hub notes system."
cssclass: kloel-hud-readme
---

<!-- AUTO-GENERATED — do not edit -->

# 📖 HUD Operator Guide

## What each hub note does

| Hub | Purpose |
|---|---|
| [[00-NEXT]] | Top 3 next tasks. First file Claude reads on session start. |
| [[00-BLOCKERS]] | Full ranked blocker queue (top 50 from BLOCKER_RANK.json). |
| [[00-DAG]] | Phase progress from CLAUDE.md DAG — completion % per phase. |
| [[00-PROVIDERS]] | Provider health (Stripe, Meta, WAHA, etc.) from Wave 1 emitter. |
| [[00-REGRESSIONS]] | What worsened since last snapshot. Baseline-only for now. |
| [[00-HUD-README]] | This file — operator guide + tag taxonomy reference. |

## Refresh

```bash
node scripts/orchestration/hud-orchestrator.mjs --once
```

Runs the full pipeline: emitters → blocker-rank → hubs-generator → graph-lens.

- `--dry` — dry run, no writes
- `--watch` — poll loop on file changes
- `--status` — print last refresh report

## Tag taxonomy

Hub-specific tags:
- `hud/hub` — all hub notes
- `hud/next`, `hud/blockers`, `hud/dag`, `hud/providers`, `hud/regressions`
- `meta/instructions` — operational docs

See [[_meta/taxonomy|Canonical Tag Taxonomy]] for the full namespace.

## Auto-gen marker

Every hub note starts with `<!-- AUTO-GENERATED — do not edit -->`.
The generator checks for this marker on every refresh:

- **Present** → overwrites file.
- **Absent** (human-edited) → aborts with a warning — manual review needed.

## Snapshots

Daily snapshots land in `Kloel/00-HUD/snapshots/YYYY-MM-DD.md` for
time-series diffing. The regressions hub will compare against the latest
snapshot once at least two exist.
