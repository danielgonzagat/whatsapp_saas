---
tags: [hud/hub, hud/blockers]
auto_generated: true
generated_at: 2026-05-03T01:28:47.593Z
purpose: "Static fallback for 00-BLOCKERS.base. Full ranked blocker queue (top 50). Prefer the .base file for interactive triage."
cssclass: kloel-hud-blockers
---

<!-- AUTO-GENERATED — do not edit -->

> **This is the static fallback view.** The preferred interactive blocker dashboard is [[00-BLOCKERS.base|00-BLOCKERS.base]]. Open that file in Obsidian for sortable, filterable, real-time blocker triage. This markdown file exists for tools that don't support the native Bases plugin (mobile, CLI, REST API rendering).

# 🚨 Full Blocker Queue (static)

**Updated**: 2026-05-03T01:28:47.593Z | **Total ranked**: 50 files

| # | File | Line | Tier | Phase | Sev. Critical | Sev. High | Score |
|---|---|---|---|---|---|---|---|
| 1 | `frontend/src/components/kloel/auth/auth-screen-data.ts` | — | tier-2 | phase-0 | 0 | 0 | 300.0 |
| 2 | `backend/src/auth/roles.guard.ts` | — | tier-2 | phase-0 | 0 | 0 | 300.0 |
| 3 | `backend/src/auth/user-name-derivation.service.ts` | — | tier-2 | phase-0 | 0 | 0 | 300.0 |
| 4 | `backend/src/auth/email-templates/data-deletion-confirmation.html` | — | tier-2 | phase-0 | 0 | 0 | 300.0 |
| 5 | `backend/src/auth/email-templates/team-invite.html` | — | tier-2 | phase-0 | 0 | 0 | 300.0 |
| 6 | `backend/src/auth/email-templates/verification.html` | — | tier-2 | phase-0 | 0 | 0 | 300.0 |
| 7 | `backend/src/auth/dto/apple-oauth.dto.ts` | — | tier-2 | phase-0 | 0 | 0 | 300.0 |
| 8 | `backend/src/auth/dto/tiktok-oauth.dto.ts` | — | tier-2 | phase-0 | 0 | 0 | 300.0 |
| 9 | `backend/src/auth/__companions__/apple-auth.service.companion.ts` | 4 | tier-2 | phase-0 | 0 | 0 | 300.0 |
| 10 | `backend/src/auth/email-templates/password-reset.html` | — | tier-2 | phase-0 | 0 | 0 | 296.1 |
| 11 | `backend/src/auth/email-templates/partner-invite.html` | — | tier-2 | phase-0 | 0 | 0 | 267.9 |
| 12 | `backend/src/checkout/checkout-product.types.ts` | — | tier-2 | phase-1 | 0 | 0 | 240.0 |
| 13 | `backend/src/checkout/dto/update-social-lead.dto.ts` | — | tier-2 | phase-1 | 0 | 0 | 240.0 |
| 14 | `backend/src/checkout/__companions__/checkout-order.service.companion.ts` | — | tier-2 | phase-1 | 0 | 0 | 240.0 |
| 15 | `backend/src/checkout/__companions__/checkout-social-lead-candidate.ts` | — | tier-2 | phase-1 | 0 | 0 | 240.0 |
| 16 | `backend/src/billing/billing-webhook.types.ts` | — | tier-2 | phase-1 | 0 | 0 | 240.0 |
| 17 | `backend/src/auth/email-templates/onboarding-day3.html` | — | tier-2 | phase-0 | 0 | 0 | 234.4 |
| 18 | `backend/src/auth/auth.token.service.spec.helpers.ts` | — | tier-2 | phase-0 | 0 | 0 | 229.6 |
| 19 | `backend/src/auth/db-init-error.service.ts` | — | tier-2 | phase-0 | 0 | 0 | 229.6 |
| 20 | `backend/src/auth/email-templates/onboarding-day7.html` | — | tier-2 | phase-0 | 0 | 0 | 220.6 |
| 21 | `frontend/src/components/kloel/auth/google-sign-in-button.helpers.ts` | — | tier-2 | phase-0 | 0 | 0 | 212.3 |
| 22 | `backend/src/auth/email-templates/onboarding-day1.html` | — | tier-2 | phase-0 | 0 | 0 | 208.3 |
| 23 | `backend/src/auth/apple-auth.support.ts` | — | tier-2 | phase-0 | 0 | 0 | 184.4 |
| 24 | `backend/src/auth/jwt-auth.helpers.ts` | 17 | tier-2 | phase-0 | 0 | 0 | 181.5 |
| 25 | `backend/src/whatsapp/whatsapp-digits.util.ts` | — | tier-2 | phase-2 | 0 | 0 | 180.0 |
| 26 | `backend/src/whatsapp/__companions__/cia-bootstrap.service.companion.ts` | — | tier-2 | phase-2 | 0 | 0 | 180.0 |
| 27 | `backend/src/whatsapp/__companions__/cia-runtime.service.fixtures.companion.ts` | — | tier-2 | phase-2 | 0 | 0 | 180.0 |
| 28 | `backend/src/checkout/checkout-product.helpers.ts` | — | tier-2 | phase-1 | 0 | 0 | 180.0 |
| 29 | `backend/src/billing/billing-plan-features.ts` | — | tier-2 | phase-1 | 0 | 0 | 173.1 |
| 30 | `backend/src/whatsapp/providers/provider-env.ts` | 40 | tier-1 | phase-2 | 0 | 0 | 168.2 |
| 31 | `backend/src/checkout/__companions__/checkout-product.service.companion.ts` | 6 | tier-2 | phase-1 | 0 | 0 | 153.8 |
| 32 | `worker/providers/whatsapp-provider-resolver.ts` | — | tier-2 | phase-2 | 0 | 0 | 153.4 |
| 33 | `backend/src/checkout/checkout-payment.service.fixtures.ts` | — | tier-2 | phase-1 | 0 | 0 | 147.5 |
| 34 | `frontend/src/components/kloel/settings/billing-legacy-providers-section.tsx` | — | tier-2 | phase-0 | 0 | 0 | 144.2 |
| 35 | `frontend/src/app/api/auth/_lib/shared-auth-cookies.ts` | — | tier-2 | phase-0 | 0 | 0 | 144.2 |
| 36 | `backend/src/checkout/checkout-public-url.util.ts` | 44 | tier-2 | phase-1 | 0 | 0 | 144.0 |
| 37 | `frontend/src/components/products/ProductCheckoutsTab.helpers.ts` | — | tier-2 | phase-1 | 0 | 0 | 136.4 |
| 38 | `backend/src/checkout/dto/update-order-status.dto.ts` | 8 | tier-2 | phase-1 | 0 | 1 | 136.4 |
| 39 | `backend/src/auth/jwt-config.ts` | 2 | tier-2 | phase-0 | 0 | 1 | 130.8 |
| 40 | `backend/src/auth/auth.module.ts` | — | tier-1 | phase-0 | 0 | 1 | 130.4 |
| 41 | `backend/src/wallet/provider-llm-billing.ts` | — | tier-2 | phase-1 | 0 | 0 | 126.8 |
| 42 | `frontend/src/components/kloel/auth/kloel-auth-screen.icons.tsx` | — | tier-2 | phase-0 | 0 | 0 | 125.0 |
| 43 | `backend/src/checkout/__companions__/checkout-catalog.service.companion.ts` | — | tier-2 | phase-1 | 0 | 0 | 125.0 |
| 44 | `backend/src/checkout/dto/create-product.dto.ts` | 6 | tier-2 | phase-1 | 0 | 1 | 123.3 |
| 45 | `frontend/src/components/kloel/settings/crm-settings-section.helpers.ts` | — | tier-2 | phase-0 | 0 | 0 | 120.0 |
| 46 | `backend/src/checkout/facebook-capi.service.ts` | — | tier-2 | phase-1 | 0 | 0 | 120.0 |
| 47 | `frontend/src/components/kloel/auth/kloel-auth-screen.social-buttons.tsx` | — | tier-2 | phase-0 | 0 | 0 | 112.5 |
| 48 | `backend/src/whatsapp/providers/__companions__/provider-send-message.ts` | — | tier-2 | phase-2 | 0 | 0 | 107.1 |
| 49 | `frontend/src/components/products/useCheckoutFormState.ts` | — | tier-2 | phase-1 | 0 | 0 | 103.4 |
| 50 | `backend/src/checkout/checkout-marketplace-pricing.util.ts` | 2 | tier-1 | phase-1 | 0 | 0 | 102.1 |

