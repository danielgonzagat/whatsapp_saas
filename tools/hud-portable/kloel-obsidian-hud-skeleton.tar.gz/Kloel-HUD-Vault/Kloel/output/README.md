---
tags:
  - meta/instructions
auto_generated: false
purpose: output folder explanation
---

# output/ — agent-generated artifacts

Disposable artifacts generated on demand: reports, generated code samples, Mermaid diagrams, slide decks (Marp).

**Lifecycle**:
- **Regenerated** any time. Do not depend on a specific output persisting.
- **Naming**: `<purpose>-<YYYYMMDD-HHmm>.md` for time-bound, `<purpose>.md` for replaceable.
- **Cleanup**: keep last 30 days; older ones can be deleted.

If an output proves valuable enough to keep, promote it to `wiki/` (with proper sources).
