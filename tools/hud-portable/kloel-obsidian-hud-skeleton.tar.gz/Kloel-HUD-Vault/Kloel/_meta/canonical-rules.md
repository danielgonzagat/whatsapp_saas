---
tags:
  - meta/instructions
  - meta/canonical
auto_generated: false
purpose: Shared guardrails for all KLOEL agents — Claude CEO + OpenCode V4 Pro subagents
generated_at: 2026-05-02
---

# KLOEL Canonical Rules

Every agent operating in this repo (`whatsapp_saas`) MUST follow these rules. Both Claude (CEO/orchestrator) and OpenCode V4 Pro subagents reference this document. No duplication across role-specific instructions docs.

## 1. Constitution-locked files (READ-ONLY, never edit)

- `scripts/obsidian-mirror-daemon*.mjs` (5 files)
- `scripts/obsidian-graph-lens.mjs`
- `scripts/pulse/**`
- `CLAUDE.md`, `AGENTS.md`
- `ops/**` (incl. `ops/protected-governance-files.json`)
- `.husky/**`, `.github/workflows/**`
- `*/eslint.config.mjs`
- `package.json` (in `protectedExact` — local commit OK, push gated)
- `backend/src/lib/{ai-models,openai-models}.ts`

## 2. Forbidden operations

- `git restore` (any form — destroys uncommitted work silently)
- `--no-verify` flag on commits/pushes (bypasses husky hooks)
- Code-disabling comments forbidden by Codacy MAX-RIGOR LOCK: `// eslint-disable`, `@ts-ignore`, `@ts-expect-error`, `@ts-nocheck`, `biome-ignore`, `nosemgrep`, `codacy:disable`, `codacy:ignore`, `NOSONAR`, `noqa`
- Commit skip-tags: `[skip ci]`, `[ci skip]`, `[codacy skip]`, `[skip codacy]`
- Echoing API keys / secrets in stdout/stderr/logs/git
- Mocking output disguised as real (must show honest empty/setup/degraded states)

## 3. Karpathy 4 principles

1. **Think Before Coding**: read first, understand, then act.
2. **Simplicity**: smallest viable change.
3. **Surgical Changes**: don't refactor what isn't asked.
4. **Goal-Driven**: every action ties back to "ship KLOEL to production".

## 4. Required practices

### 4.1 Atomic writes
tmp + rename. Never partial-write a file other agents read.

### 4.2 Idempotency
Detect existing state, skip if no change. Same prompt twice → same outcome.

### 4.3 JSON envelope end-of-reply
Base format (closing every reply):
```json
{"subagent":"<name>","files_created":[...],"files_modified":[...],"commands_run":[...],"status":"pass|partial|fail","blockers":""}
```
OpenCode subagents extend this with `pulse_break_resolved`, `ratchet_check`, `sentry_clean`, `e2e_evidence`, `residual_risk` fields.

### 4.4 Lowercase commit subjects
Commitlint enforces lowercase. Format: `type(scope): subject`. Example: `fix(billing): wrap stripe balance ops in $transaction [PULSE break #1]`

### 4.5 Manifest.id invariant
When installing plugins: folder name MUST equal `manifest.json.id`, never the repo name.

### 4.6 Hung detection self-check
If reading >50 individual files of similar shape, STOP. Write a script that iterates instead. Never iterate in your context.

### 4.7 Token economy
UNLIMITED budget. Be verbose, detailed, self-contained. Don't summarize prematurely.

## 5. Validation gates

Before declaring work done, run:

```bash
npm run check:all             # all preflight gates
npm run check:governance      # protected-files boundary
npm run typecheck             # TS for backend+frontend+worker
npm run test:coverage         # coverage all 3 services
npm run quality:graph:strict  # madge cycles
npm run quality:dead-code:strict   # knip
npm run quality:static        # format + guard:new-code + architecture + seatbelt + ratchet
npm run codacy:check-max-rigor     # Codacy drift
npm run ratchet:check         # ratchet floors not regressed
```

E2E proof requires real production hit: Vercel → Railway → DB → event → response, with Sentry trace clean. Mocked passes do NOT count.

## 6. PULSE — canonical truth

Run from repo root:
```bash
npm run pulse                  # writes PULSE_HEALTH.json, PULSE_REPORT.md, PULSE_WORLD_STATE.json, PULSE_CLI_DIRECTIVE.json, PULSE_CERTIFICATE.json
npm run pulse:report           # human-readable
npm run pulse:json             # JSON
npm run pulse:certify          # gate
```

**Decision authority**: `PULSE_HEALTH.json` + `PULSE_CLI_DIRECTIVE.json` + `ratchet.json` are the canonical truth. Obsidian graph is projection (cognitive aid), never decision-making.

## 7. Workspace lock check (before edit)

A file with `#workspace/dirty` tag in its mirror frontmatter has uncommitted changes. **Don't edit it** — another agent or human is working there. Wait for the lock to drop (after commit, daemon clears the tag automatically).

```bash
grep -l '#workspace/dirty' "$VAULT/Kloel/99 - Espelho do Codigo/_source/<file>.md"

# Or via REST:
curl -ksS -H "Authorization: Bearer $KEY" "https://localhost:27124/search/dataview" \
  -X POST -d '{"query":"LIST FROM #workspace/dirty"}'
```

## 8. Memory updates

If you discover a new failure mode or a pattern worth preserving, update memory immediately via `MEMORY.md` (indexed at `__KLOEL_HOME__/.claude/projects/-Users-danielpenin-whatsapp-saas/memory/MEMORY.md`).

## 9. Sidecar pipeline (read-only, emit canonical scripts only)

To regenerate sidecars after work: `node scripts/orchestration/hud-orchestrator.mjs --once` (idempotent, ~3min cold).

## 10. KLOEL truth principle

> KLOEL is not a SaaS with AI. KLOEL is AI that manifests as SaaS.

Every line of code must serve real production functioning, not appearance. The Obsidian graph is the organism's ECG — we cure the patient, we don't fake the ECG.
