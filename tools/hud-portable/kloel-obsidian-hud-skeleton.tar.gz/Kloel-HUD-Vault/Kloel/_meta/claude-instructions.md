---
tags:
  - meta/instructions
auto_generated: false
purpose: Claude session-start protocol for KLOEL HUD
generated_at: 2026-05-02
---

# Claude Session-Start Protocol

When opening a new Claude Code session in this repo (`whatsapp_saas`), execute in this exact order:

## 1. Read MEMORY.md FIRST
`__KLOEL_HOME__/.claude/projects/-Users-danielpenin-whatsapp-saas/memory/MEMORY.md` — index of all permanent learnings.

## 2. Query 00-NEXT.md via MCP
Once Wave 2 H1 has generated it. Use MCP tool:
```
obsidian_get_note(path="Kloel/00-HUD/00-NEXT.md")
```
~80 tokens. First file you read gives top-3 ranked blockers.

## 3. Heavy work → OpenCode V4 Pro subagents
Never use Claude Agent tool (Explore, general-purpose, etc). Always:
```bash
opencode run --pure -m deepseek/deepseek-v4-pro --format json --dangerously-skip-permissions --dir <scope> "<prompt>"
```

## 4. Shared guardrails

All shared rules — constitution-locked files, forbidden operations, required practices, validation gates, PULSE truth, workspace locks, memory updates — live in:

→ **[[Kloel/_meta/canonical-rules]]**

Read canonical-rules.md before every session. Do not duplicate those rules here.

## 5. Orchestrator decisions (Claude-only)

As CEO/orchestrator, you decide **WHAT** and **WHY**. OpenCode subagents execute the **HOW**. Your unique responsibilities:

- **Triage**: rank blockers from `00-NEXT.md` against PULSE health + ratchet regressions.
- **Dispatch**: choose `--dir <scope>` and craft self-contained prompts for subagents. Include canonical-rules reference in every dispatch.
- **Merge decisions**: after subagent delivery + validation gate passes, decide to merge or iterate.
- **Strategy**: when a pulse break or blocker re-appears after subagent claim of fix, root-cause the orchestrator problem (bad prompt, wrong scope, missing context) — don't just re-dispatch the same task.

## 6. Validation gate

After every delivery, launch validation swarm per feedback_validation_swarm_pattern.md, then run the canonical validation gates.

## 7. Memory updates

If you discover a new failure mode or a pattern worth preserving, update MEMORY.md immediately. See canonical-rules.md §8 for detail.
