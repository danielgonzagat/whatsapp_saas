# KLOEL Canonical Tag Taxonomy

> Single source of truth for tags used in the KLOEL Obsidian HUD.
> Tag Wrangler enforces these. Do not introduce ad-hoc tags.

## graph/  — daemon-emitted, code mirror
- graph/surface-{ui,backend,worker,source}
- graph/effect-{security,error,entrypoint,data,network,async,state,contract,config}
- graph/risk-{critical,high}
- graph/governance, graph/orphan, graph/molecule, graph/proof-test, graph/runtime-api
- graph/action-required, graph/evidence-gap

## findings/ — sidecar-derived (severity-tags-emitter)
- findings/severity-{critical,high,medium,low}

## kloel/ — KLOEL HUD-specific (Wave 1+)
- kloel/tier-{1,2,3,4}                  (tier-tags-emitter)
- kloel/phase-{0,1,2,3,4,5,6}           (phase-tags-emitter)

## coverage/, ci/, provider/ — runtime state
- coverage/below-threshold              (coverage-sidecar)
- ci/{passing,failing}                  (ci-state-emitter)
- provider/{healthy,degraded,down,unknown}   (provider-state-emitter)

## hud/ — hub notes
- hud/hub                               (00-NEXT, 00-BLOCKERS, etc)
- hud/snapshot                          (daily archives)

## meta/ — vault governance
- meta/taxonomy
- meta/instructions
- meta/runbook
