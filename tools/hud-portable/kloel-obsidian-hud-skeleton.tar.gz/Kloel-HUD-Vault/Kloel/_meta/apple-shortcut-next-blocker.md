---
tags:
  - meta/shortcut
  - tooling/automation
created: 2026-05-03
purpose: "Apple Shortcut: speak KLOEL's top blocker aloud via Siri or hotkey"
---

# Apple Shortcut — "Next KLOEL Blocker"

Voice trigger: **"next KLOEL blocker"** (customizable below).

This shortcut queries the Obsidian Local REST API, extracts the #1 blocker from `00-NEXT.md`, and speaks it aloud. Works on macOS (Shortcuts.app — can bind to keyboard) and iOS (Siri / Shortcuts widget).

## Prerequisites

- Obsidian running with the **Local REST API** plugin enabled (v3.6.1+)
- Your API key (find it in Obsidian → Local REST API plugin settings, or extract from `~/.claude.json`):
  ```bash
  jq -r '.projects["__KLOEL_REPO_ROOT__"].mcpServers.obsidian.env.OBSIDIAN_API_KEY' ~/.claude.json
  ```
- macOS: Shortcuts.app (built-in, macOS 12+)
- iOS: Shortcuts.app (built-in, iOS 13+)

## Step-by-step — build in Shortcuts.app

Open Shortcuts.app → click `+` to create a new shortcut. Add the following actions in order.

---

### Step 1 — Get Contents of URL

| Field | Value |
|---|---|
| **Action** | `Get Contents of URL` (search "URL") |
| **URL** | `https://localhost:27124/vault/Kloel/00-HUD/00-NEXT.md` |
| **Method** | `GET` |
| **Headers** | Add one header: `Authorization` / `Bearer YOUR_API_KEY_HERE` |

> **Important**: After adding the action, tap/click **Show More** (or the `↕` expand arrow on macOS), then enable:
> - **Allow Untrusted Hosts** → ON

This bypasses the self-signed cert rejection (HTTPS over localhost with Obsidian's cert).

---

### Step 2 — Get Text from Input (macOS shortcut — may be auto-implied)

On macOS, Shortcuts.app automatically treats the response as text, so you may skip this. If iOS or the next action doesn't see text, add:

| Field | Value |
|---|---|
| **Action** | `Get Text from Input` |

Insert between Step 1 and Step 3. In most cases **not needed**.

---

### Step 3 — Match Text (regex)

| Field | Value |
|---|---|
| **Action** | `Match Text` |
| **Pattern** | `\| 1 \| [^|]* \| ([^|]+)` |
| **Case Sensitive** | OFF |

**What this does**: Finds the table row starting with `| 1 |`, skips the File:Line column (`[^|]*`), and captures the "Why" column (the blocker description). The capture group `([^|]+)` is what gets spoken.

Example match from the current `00-NEXT.md`:
- Captures: `No findings — code audit recommended`

**Alternative regex** (captures the full `File:Line — Why` as one string):
```
\| 1 \| ([^|]+) \| ([^|]+)
```
Use capture group 1 for file, capture group 2 for why. Shortcuts uses the first group by default.

---

### Step 4 — Speak Text

| Field | Value |
|---|---|
| **Action** | `Speak Text` |
| **Input** | `Match Text` (the output of Step 3 — Shortcuts auto-pipes variables) |

For additional polish — Add a text action before Speak to prepend a prefix:

1. Add action: `Text` with value: `KLOEL's top blocker is: ` (with trailing space)
2. Add action: `Combine Text` → combine the prefix + the Match result
3. Feed combined text into `Speak Text`

---

## Voice trigger setup

### On macOS

1. In Shortcuts.app, double-click the shortcut name at the top (default: "Untitled Shortcut")
2. Name it: `Next KLOEL Blocker`
3. **Optional: Assign a keyboard shortcut**:
   - Apple Menu → System Settings → Keyboard → Keyboard Shortcuts → Services → Shortcuts
   - Find "Next KLOEL Blocker" and assign e.g. `⌃⌥⌘K`

### On iOS

1. Name the shortcut: `Next KLOEL Blocker` (this is the phrase Siri listens for)
2. Say: **"Hey Siri, next KLOEL blocker"**
3. Or: add a home screen widget or back-tap trigger in Settings → Accessibility → Touch → Back Tap

---

## What you'll hear

```
KLOEL's top blocker is: No findings — code audit recommended
```

The spoken text is the "Why" column from the first ranked blocker in `00-NEXT.md`.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| "Could not connect to the server" | Obsidian not running or Local REST API not enabled | Open Obsidian, check Community Plugins → Local REST API is ON and shows port 27124 |
| "SSL error" / untrusted host | `Allow Untrusted Hosts` not enabled | Enable it in Get Contents of URL → Show More |
| "No matches found" | Regex doesn't match the current table format | HUD file format may have changed. Check `00-NEXT.md` table structure and update regex |
| "Authentication failed" | Wrong API key | Copy the key from Obsidian → Local REST API settings, or extract via the `jq` command above |
| Speaks "nil" or empty | Regex matched but capture group empty | Add a `Text` action after Match Text to debug: pass Matches → `Show Result` (temporarily) to see what was captured |

---

## Testing the REST endpoint manually

Before building the shortcut, verify the API works:

```bash
KEY=$(jq -r '.projects["__KLOEL_REPO_ROOT__"].mcpServers.obsidian.env.OBSIDIAN_API_KEY' ~/.claude.json)
curl -ksS -H "Authorization: Bearer $KEY" \
  "https://localhost:27124/vault/Kloel/00-HUD/00-NEXT.md"
```

Expected output: the full contents of `00-NEXT.md` (the same file shown in Obsidian).

---

## Companion files

- `<vault>/Kloel/_meta/shortcut-export-template.shortcut.json` — JSON template for possible import
- `<vault>/Kloel/00-HUD/00-NEXT.md` — the HUD file this shortcut reads
- `<vault>/Kloel/_meta/hud-refresh.md` — how to refresh the HUD file (so blocker list is current)
