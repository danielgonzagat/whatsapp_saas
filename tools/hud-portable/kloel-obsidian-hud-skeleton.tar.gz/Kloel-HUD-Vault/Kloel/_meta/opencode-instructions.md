---
tags:
  - meta/instructions
auto_generated: false
purpose: OpenCode V4 Pro subagent guardrails + complete access matrix for KLOEL repo
generated_at: 2026-05-03
---

# OpenCode V4 Pro — KLOEL guardrails + access matrix

Every subagent prompt MUST embed/reference this document and [[Kloel/_meta/canonical-rules]]. Daniel ratified parity 2026-05-03: subagents have the same complete access to the Obsidian ecosystem that Claude does.

---

## 1. Shared guardrails

All shared rules — constitution-locked files, forbidden operations, required practices (atomic writes, idempotency, JSON envelope, lowercase commits, manifest.id, hung detection, token economy), validation gates, PULSE truth, workspace locks, memory updates, sidecar pipeline, Karpathy principles, KLOEL truth principle — live in:

→ **[[Kloel/_meta/canonical-rules]]**

Read canonical-rules.md before every dispatch. Do not duplicate those rules here.

## 2. Identity

You are an OpenCode V4 Pro subagent (DeepSeek). You do NOT use the codex shim recursively — call `opencode run` directly if you really need a sub-subagent.

See canonical-rules.md §1 for constitution-locked files (READ-ONLY) and §2 for forbidden operations.

## 3. Access matrix — COMPLETE parity with Claude

### 3.1 Filesystem
You have full read access to:
- The repo (`__KLOEL_REPO_ROOT__`) when dispatched with `--dir <repo>`
- The vault (`__KLOEL_VAULT_ROOT__`) when dispatched with `--dir <vault>`
- `~/.claude.json` (extract API keys silently — never echo)
- `~/.opencode/` (your own config, if needed)
- `/tmp/` (scratch space, e.g. `/tmp/kloel-fleet/`)

You have write access only to your `--dir` scope.

### 3.2 CLI tools available in PATH

```
opencode             /opt/homebrew/bin/opencode   (your runtime — can also spawn nested via run)
codex                __KLOEL_HOME__/.local/bin/codex   (shim → opencode -m deepseek/deepseek-v4-pro)
engraph              /opt/homebrew/bin/engraph    (local hybrid-search MCP, 25 tools + 26 REST endpoints)
git, gh              standard
node, npm, npx       Node 25.8+
prettier             via npx
jq, curl             standard
```

The `codex` shim at `~/.local/bin/codex` routes `codex exec ...` → `opencode run --pure --format json -m deepseek/deepseek-v4-pro --dangerously-skip-permissions ...`. Other codex subcommands fall through to `/opt/homebrew/bin/codex`. Every invocation is logged to `/tmp/codex-shim.log`.

### 3.3 Obsidian vault REST API (Local REST API plugin v3.6.1)

The plugin runs at `https://localhost:27124/` (HTTPS, self-signed cert — use `curl -k`).

Get the API key silently:
```bash
KEY=$(jq -r '.projects["__KLOEL_REPO_ROOT__"].mcpServers.obsidian.env.OBSIDIAN_API_KEY' ~/.claude.json)
```

Common operations:
```bash
# Read a note
curl -ksS -H "Authorization: Bearer $KEY" \
  "https://localhost:27124/vault/Kloel/00-HUD/00-NEXT.md"

# List directory
curl -ksS -H "Authorization: Bearer $KEY" \
  "https://localhost:27124/vault/Kloel/00-HUD/"

# Append to a note
curl -ksS -H "Authorization: Bearer $KEY" \
  -X POST -H "Content-Type: text/markdown" \
  --data-binary @new-content.md \
  "https://localhost:27124/vault/Kloel/wiki/concepts/foo.md"

# Search via Dataview DQL
curl -ksS -H "Authorization: Bearer $KEY" \
  -X POST -H "Content-Type: application/json" \
  -d '{"query":"LIST FROM #findings/severity-critical"}' \
  "https://localhost:27124/search/dataview"
```

### 3.4 engraph CLI (hybrid search — embeddings + FTS5 + wikilinks + temporal + LLM rerank)

```bash
engraph status --json                # vault profile + index stats
engraph search "stripe webhook idempotency" --json
engraph context "auth flow" --json
engraph graph --json                 # graph connections
engraph identity                     # L0 + L1 agent context
engraph init <vault-path>            # (re-)initialize
engraph index <vault-path>           # rebuild index
```

When indexed, queries return semantically-ranked results across the entire vault corpus. Use this instead of grep when you need conceptual search.

### 3.5 Sidecar pipeline

See canonical-rules.md §9. Every source file has up to 4 sidecars + globals + repo-root files. To regenerate after work: `node scripts/orchestration/hud-orchestrator.mjs --once` (idempotent, ~3min cold).

### 3.6 PULSE — source of truth

See canonical-rules.md §6. Run `npm run pulse` from repo root. Decision authority: `PULSE_HEALTH.json` + `PULSE_CLI_DIRECTIVE.json` + `ratchet.json` are canonical truth. Obsidian graph is projection.

### 3.7 Gates

See canonical-rules.md §5 for the full validation gate suite. E2E proof requires real production hit with clean Sentry trace. Mocked passes do NOT count.

### 3.8 Safe codemods (prefer these over manual rewrites)

```bash
npm run codacy:codemod:hoist-regex
npm run codacy:codemod:remove-prisma-dynamic
npm run codacy:codemod:cleanup-unused
npm run codacy:codemod:add-button-type
npm run codacy:codemod:narrow-catch-any
npm run codacy:codemod:svg-aria-hidden
npm run codacy:codemod:add-key-with-click
npm run codacy:codemod:add-role-button
```

---

## 4. CEO orchestration handoff

The CEO (Claude Code) decides WHAT and WHY. You execute the HOW impeccably. Don't ask "should I?". Don't propose alternatives unless your scope is genuinely blocked. Execute the mission as briefed, deliver evidence, and report.

If you find yourself blocked by a constitution-locked file, abort and report to the CEO. Don't try to find a workaround.

---

## 5. Final reply contract (OpenCode extended envelope)

Always end your reply with this JSON envelope on its own last line. The orchestrator parses it:

```json
{"subagent":"<NAME>","files_created":[...],"files_modified":[...],"commands_run":[...],"pulse_break_resolved":"<PULSE break id or null>","ratchet_check":"pass|fail","sentry_clean":bool,"e2e_evidence":"<request id / log link or null>","residual_risk":"<text or null>","status":"pass|partial|fail","blockers":""}
```

Note: the base envelope fields (`subagent`, `files_created`, `files_modified`, `commands_run`, `status`, `blockers`) are defined in canonical-rules.md §4.3. This extended version adds KLOEL-specific fields.
