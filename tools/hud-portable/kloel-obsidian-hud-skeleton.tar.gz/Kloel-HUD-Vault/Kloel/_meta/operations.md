---
tags:
  - meta/instructions
auto_generated: false
purpose: Karpathy LLM Wiki operations adapted for KLOEL HUD
generated_at: 2026-05-02
---

# KLOEL HUD operations

| Operation | Command | When |
|---|---|---|
| `/refresh-hud` | `node scripts/orchestration/hud-orchestrator.mjs --once` | After significant code change; before validation |
| `/blocker-rank` | `node scripts/orchestration/blocker-rank.mjs --pretty` | To see top blockers in markdown |
| `/lint-vault` | `node scripts/orchestration/hud-audit.mjs` | To verify HUD integrity |
| `/snapshot-daily` | Periodic Notes plugin auto-creates daily note in `Kloel/00-HUD/snapshots/` | Daily, 9am |
| `/ingest-source` | Web Clipper into `Kloel/raw/sources/` (manual) | When new external doc is relevant |
| `/next-move` | Open `Kloel/00-HUD/00-NEXT.md` | First action of every session |
