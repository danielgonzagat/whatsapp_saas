---
tags:
  - meta/instructions
auto_generated: false
purpose: raw sources folder explanation
---

# raw/ — immutable sources

Files in this folder are **immutable evidence**. Do not edit.

**Sources**: GitHub release notes, Stripe docs, Meta API docs, Sentry incident reports, Vercel changelogs, AWS pricing pages, ADRs we ingest from external repos.

**Lifecycle**:
- **Captured** via Obsidian Web Clipper, `gh api`, or manual paste.
- **Tagged** with `meta/source` + originating provider tag.
- **Linked** from `wiki/` notes when synthesized.
- **Never edited** — if a source updates, capture a new copy with date suffix.

This is the "Karpathy LLM Wiki" pattern. Quality gate at ingestion matters more than retrieval optimization.
