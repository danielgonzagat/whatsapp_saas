---
title: "frontend/src/components/kloel/auth/auth-screen-data.ts"
status: open
priority: high
tier: 2
phase: 0
score: 300
effort_hours: 0.5
file: frontend/src/components/kloel/auth/auth-screen-data.ts
top_finding: "none"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-2
created: 2026-05-03T01:27:42.960Z
auto_generated: true
---

# frontend/src/components/kloel/auth/auth-screen-data.ts

**Score**: 300 · **Tier**: 2 · **Phase**: 0 · **Effort**: 0.5h

## Top finding
- findings: 0 (no linter/PULSE findings for this file)

## Why ranked here
- tier_weight: 3
- phase_priority: 10
- user_impact: 5
- effort_hours: 0.5

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/frontend/src/components/kloel/auth/auth-screen-data.ts]]
- Open in editor: `code frontend/src/components/kloel/auth/auth-screen-data.ts`
