---
title: "frontend/src/components/products/ProductCheckoutsTab.helpers.ts"
status: open
priority: low
tier: 2
phase: 1
score: 136.36363636363637
effort_hours: 0.9
file: frontend/src/components/products/ProductCheckoutsTab.helpers.ts
top_finding: "none"
tags:
  - hud/task
  - kloel/phase-1
  - kloel/tier-2
created: 2026-05-03T01:27:42.968Z
auto_generated: true
---

# frontend/src/components/products/ProductCheckoutsTab.helpers.ts

**Score**: 136.36363636363637 · **Tier**: 2 · **Phase**: 1 · **Effort**: 0.9h

## Top finding
- findings: 0 (no linter/PULSE findings for this file)

## Why ranked here
- tier_weight: 3
- phase_priority: 8
- user_impact: 5
- effort_hours: 0.9

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/frontend/src/components/products/ProductCheckoutsTab.helpers.ts]]
- Open in editor: `code frontend/src/components/products/ProductCheckoutsTab.helpers.ts`
