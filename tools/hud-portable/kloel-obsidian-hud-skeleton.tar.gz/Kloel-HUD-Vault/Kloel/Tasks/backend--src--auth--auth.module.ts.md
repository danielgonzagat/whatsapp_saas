---
title: "backend/src/auth/auth.module.ts"
status: open
priority: low
tier: 1
phase: 0
score: 130.43478260869566
effort_hours: 1.5
file: backend/src/auth/auth.module.ts
top_finding: "madge/circular"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-1
created: 2026-05-03T01:27:42.969Z
auto_generated: true
---

# backend/src/auth/auth.module.ts

**Score**: 130.43478260869566 · **Tier**: 1 · **Phase**: 0 · **Effort**: 1.5h

## Top finding
- engine: madge
- rule: madge/circular
- line: undefined
- message: "circular dependency in cycle: backend/src/auth/auth.module.ts → backend/src/notifications/notifications.module.ts → backend/src/auth/auth.module.ts"

## Why ranked here
- tier_weight: 4
- phase_priority: 10
- user_impact: 5
- effort_hours: 1.5

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/auth/auth.module.ts]]
- Open in editor: `code backend/src/auth/auth.module.ts`
