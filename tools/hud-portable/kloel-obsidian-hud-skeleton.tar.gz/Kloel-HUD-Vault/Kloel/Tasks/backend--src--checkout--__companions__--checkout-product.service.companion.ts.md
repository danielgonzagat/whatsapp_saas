---
title: "backend/src/checkout/__companions__/checkout-product.service.companion.ts"
status: open
priority: low
tier: 2
phase: 1
score: 153.84615384615384
effort_hours: 0.8
file: backend/src/checkout/__companions__/checkout-product.service.companion.ts
top_finding: "knip/unused-type"
tags:
  - hud/task
  - kloel/phase-1
  - kloel/tier-2
created: 2026-05-03T01:27:42.967Z
auto_generated: true
---

# backend/src/checkout/__companions__/checkout-product.service.companion.ts

**Score**: 153.84615384615384 · **Tier**: 2 · **Phase**: 1 · **Effort**: 0.8h

## Top finding
- engine: knip
- rule: knip/unused-type
- line: 6
- message: "unused type: CreateCheckoutDeps"

## Why ranked here
- tier_weight: 3
- phase_priority: 8
- user_impact: 5
- effort_hours: 0.8

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/checkout/__companions__/checkout-product.service.companion.ts]]
- Open in editor: `code backend/src/checkout/__companions__/checkout-product.service.companion.ts`
