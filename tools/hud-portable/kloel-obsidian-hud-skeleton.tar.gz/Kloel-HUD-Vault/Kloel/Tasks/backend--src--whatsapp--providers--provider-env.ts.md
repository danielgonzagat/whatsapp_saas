---
title: "backend/src/whatsapp/providers/provider-env.ts"
status: open
priority: low
tier: 1
phase: 2
score: 168.22429906542055
effort_hours: 0.7
file: backend/src/whatsapp/providers/provider-env.ts
top_finding: "knip/unused-export"
tags:
  - hud/task
  - kloel/phase-2
  - kloel/tier-1
created: 2026-05-03T01:27:42.967Z
auto_generated: true
---

# backend/src/whatsapp/providers/provider-env.ts

**Score**: 168.22429906542055 · **Tier**: 1 · **Phase**: 2 · **Effort**: 0.7h

## Top finding
- engine: knip
- rule: knip/unused-export
- line: 40
- message: "unused export: isWahaRuntimeConfigured"

## Why ranked here
- tier_weight: 4
- phase_priority: 6
- user_impact: 5
- effort_hours: 0.7

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/whatsapp/providers/provider-env.ts]]
- Open in editor: `code backend/src/whatsapp/providers/provider-env.ts`
