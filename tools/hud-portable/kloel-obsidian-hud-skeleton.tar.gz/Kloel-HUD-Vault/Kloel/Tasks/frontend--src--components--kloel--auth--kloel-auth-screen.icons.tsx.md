---
title: "frontend/src/components/kloel/auth/kloel-auth-screen.icons.tsx"
status: open
priority: low
tier: 2
phase: 0
score: 125
effort_hours: 1.2
file: frontend/src/components/kloel/auth/kloel-auth-screen.icons.tsx
top_finding: "none"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-2
created: 2026-05-03T01:27:42.969Z
auto_generated: true
---

# frontend/src/components/kloel/auth/kloel-auth-screen.icons.tsx

**Score**: 125 · **Tier**: 2 · **Phase**: 0 · **Effort**: 1.2h

## Top finding
- findings: 0 (no linter/PULSE findings for this file)

## Why ranked here
- tier_weight: 3
- phase_priority: 10
- user_impact: 5
- effort_hours: 1.2

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/frontend/src/components/kloel/auth/kloel-auth-screen.icons.tsx]]
- Open in editor: `code frontend/src/components/kloel/auth/kloel-auth-screen.icons.tsx`
