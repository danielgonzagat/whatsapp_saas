---
title: "backend/src/checkout/facebook-capi.service.ts"
status: open
priority: low
tier: 2
phase: 1
score: 120
effort_hours: 1.0
file: backend/src/checkout/facebook-capi.service.ts
top_finding: "none"
tags:
  - hud/task
  - kloel/phase-1
  - kloel/tier-2
created: 2026-05-03T01:27:42.970Z
auto_generated: true
---

# backend/src/checkout/facebook-capi.service.ts

**Score**: 120 · **Tier**: 2 · **Phase**: 1 · **Effort**: 1.0h

## Top finding
- findings: 0 (no linter/PULSE findings for this file)

## Why ranked here
- tier_weight: 3
- phase_priority: 8
- user_impact: 5
- effort_hours: 1.0

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/checkout/facebook-capi.service.ts]]
- Open in editor: `code backend/src/checkout/facebook-capi.service.ts`
