---
title: "backend/src/billing/billing-plan-features.ts"
status: open
priority: low
tier: 2
phase: 1
score: 173.07692307692307
effort_hours: 0.7
file: backend/src/billing/billing-plan-features.ts
top_finding: "none"
tags:
  - hud/task
  - kloel/phase-1
  - kloel/tier-2
created: 2026-05-03T01:27:42.967Z
auto_generated: true
---

# backend/src/billing/billing-plan-features.ts

**Score**: 173.07692307692307 · **Tier**: 2 · **Phase**: 1 · **Effort**: 0.7h

## Top finding
- findings: 0 (no linter/PULSE findings for this file)

## Why ranked here
- tier_weight: 3
- phase_priority: 8
- user_impact: 5
- effort_hours: 0.7

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/billing/billing-plan-features.ts]]
- Open in editor: `code backend/src/billing/billing-plan-features.ts`
