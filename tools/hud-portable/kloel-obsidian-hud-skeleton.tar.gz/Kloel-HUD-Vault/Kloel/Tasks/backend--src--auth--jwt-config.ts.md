---
title: "backend/src/auth/jwt-config.ts"
status: open
priority: low
tier: 2
phase: 0
score: 130.8139534883721
effort_hours: 1.1
file: backend/src/auth/jwt-config.ts
top_finding: "knip/unlisted-dependency"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-2
created: 2026-05-03T01:27:42.969Z
auto_generated: true
---

# backend/src/auth/jwt-config.ts

**Score**: 130.8139534883721 · **Tier**: 2 · **Phase**: 0 · **Effort**: 1.1h

## Top finding
- engine: knip
- rule: knip/unlisted-dependency
- line: 2
- message: "unlisted import: jsonwebtoken"

## Why ranked here
- tier_weight: 3
- phase_priority: 10
- user_impact: 5
- effort_hours: 1.1

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/auth/jwt-config.ts]]
- Open in editor: `code backend/src/auth/jwt-config.ts`
