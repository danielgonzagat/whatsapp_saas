---
title: "backend/src/auth/email-templates/onboarding-day3.html"
status: open
priority: medium
tier: 2
phase: 0
score: 234.375
effort_hours: 0.6
file: backend/src/auth/email-templates/onboarding-day3.html
top_finding: "none"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-2
created: 2026-05-03T01:27:42.965Z
auto_generated: true
---

# backend/src/auth/email-templates/onboarding-day3.html

**Score**: 234.375 · **Tier**: 2 · **Phase**: 0 · **Effort**: 0.6h

## Top finding
- findings: 0 (no linter/PULSE findings for this file)

## Why ranked here
- tier_weight: 3
- phase_priority: 10
- user_impact: 5
- effort_hours: 0.6

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/auth/email-templates/onboarding-day3.html]]
- Open in editor: `code backend/src/auth/email-templates/onboarding-day3.html`
