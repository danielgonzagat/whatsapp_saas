---
title: "backend/src/auth/apple-auth.support.ts"
status: open
priority: medium
tier: 2
phase: 0
score: 184.4262295081967
effort_hours: 0.8
file: backend/src/auth/apple-auth.support.ts
top_finding: "none"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-2
created: 2026-05-03T01:27:42.966Z
auto_generated: true
---

# backend/src/auth/apple-auth.support.ts

**Score**: 184.4262295081967 · **Tier**: 2 · **Phase**: 0 · **Effort**: 0.8h

## Top finding
- findings: 0 (no linter/PULSE findings for this file)

## Why ranked here
- tier_weight: 3
- phase_priority: 10
- user_impact: 5
- effort_hours: 0.8

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/auth/apple-auth.support.ts]]
- Open in editor: `code backend/src/auth/apple-auth.support.ts`
