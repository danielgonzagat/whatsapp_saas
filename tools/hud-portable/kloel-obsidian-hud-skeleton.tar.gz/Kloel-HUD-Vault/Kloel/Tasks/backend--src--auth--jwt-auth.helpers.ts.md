---
title: "backend/src/auth/jwt-auth.helpers.ts"
status: open
priority: medium
tier: 2
phase: 0
score: 181.4516129032258
effort_hours: 0.8
file: backend/src/auth/jwt-auth.helpers.ts
top_finding: "knip/unused-export"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-2
created: 2026-05-03T01:27:42.966Z
auto_generated: true
---

# backend/src/auth/jwt-auth.helpers.ts

**Score**: 181.4516129032258 · **Tier**: 2 · **Phase**: 0 · **Effort**: 0.8h

## Top finding
- engine: knip
- rule: knip/unused-export
- line: 17
- message: "unused export: extractBearerToken"

## Why ranked here
- tier_weight: 3
- phase_priority: 10
- user_impact: 5
- effort_hours: 0.8

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/auth/jwt-auth.helpers.ts]]
- Open in editor: `code backend/src/auth/jwt-auth.helpers.ts`
