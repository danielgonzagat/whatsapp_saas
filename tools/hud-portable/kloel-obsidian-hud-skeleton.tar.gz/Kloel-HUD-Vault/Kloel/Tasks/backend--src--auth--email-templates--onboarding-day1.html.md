---
title: "backend/src/auth/email-templates/onboarding-day1.html"
status: open
priority: medium
tier: 2
phase: 0
score: 208.33333333333334
effort_hours: 0.7
file: backend/src/auth/email-templates/onboarding-day1.html
top_finding: "none"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-2
created: 2026-05-03T01:27:42.966Z
auto_generated: true
---

# backend/src/auth/email-templates/onboarding-day1.html

**Score**: 208.33333333333334 · **Tier**: 2 · **Phase**: 0 · **Effort**: 0.7h

## Top finding
- findings: 0 (no linter/PULSE findings for this file)

## Why ranked here
- tier_weight: 3
- phase_priority: 10
- user_impact: 5
- effort_hours: 0.7

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/auth/email-templates/onboarding-day1.html]]
- Open in editor: `code backend/src/auth/email-templates/onboarding-day1.html`
