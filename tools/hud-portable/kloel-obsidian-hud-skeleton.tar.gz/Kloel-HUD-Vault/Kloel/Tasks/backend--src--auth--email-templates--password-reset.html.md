---
title: "backend/src/auth/email-templates/password-reset.html"
status: open
priority: high
tier: 2
phase: 0
score: 296.05263157894734
effort_hours: 0.5
file: backend/src/auth/email-templates/password-reset.html
top_finding: "none"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-2
created: 2026-05-03T01:27:42.963Z
auto_generated: true
---

# backend/src/auth/email-templates/password-reset.html

**Score**: 296.05263157894734 · **Tier**: 2 · **Phase**: 0 · **Effort**: 0.5h

## Top finding
- findings: 0 (no linter/PULSE findings for this file)

## Why ranked here
- tier_weight: 3
- phase_priority: 10
- user_impact: 5
- effort_hours: 0.5

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/auth/email-templates/password-reset.html]]
- Open in editor: `code backend/src/auth/email-templates/password-reset.html`
