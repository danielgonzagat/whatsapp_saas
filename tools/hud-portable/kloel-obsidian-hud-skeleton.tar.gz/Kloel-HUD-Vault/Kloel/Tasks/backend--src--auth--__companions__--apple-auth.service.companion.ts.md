---
title: "backend/src/auth/__companions__/apple-auth.service.companion.ts"
status: open
priority: high
tier: 2
phase: 0
score: 300
effort_hours: 0.5
file: backend/src/auth/__companions__/apple-auth.service.companion.ts
top_finding: "knip/unused-export"
tags:
  - hud/task
  - kloel/phase-0
  - kloel/tier-2
created: 2026-05-03T01:27:42.963Z
auto_generated: true
---

# backend/src/auth/__companions__/apple-auth.service.companion.ts

**Score**: 300 · **Tier**: 2 · **Phase**: 0 · **Effort**: 0.5h

## Top finding
- engine: knip
- rule: knip/unused-export
- line: 4
- message: "unused export: encodeAuthJson"

## Why ranked here
- tier_weight: 3
- phase_priority: 10
- user_impact: 5
- effort_hours: 0.5

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/auth/__companions__/apple-auth.service.companion.ts]]
- Open in editor: `code backend/src/auth/__companions__/apple-auth.service.companion.ts`
