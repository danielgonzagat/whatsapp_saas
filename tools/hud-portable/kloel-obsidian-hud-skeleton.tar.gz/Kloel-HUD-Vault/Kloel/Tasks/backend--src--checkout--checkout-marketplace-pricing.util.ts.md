---
title: "backend/src/checkout/checkout-marketplace-pricing.util.ts"
status: open
priority: low
tier: 1
phase: 1
score: 102.12765957446808
effort_hours: 1.6
file: backend/src/checkout/checkout-marketplace-pricing.util.ts
top_finding: "knip/unused-type"
tags:
  - hud/task
  - kloel/phase-1
  - kloel/tier-1
created: 2026-05-03T01:27:42.971Z
auto_generated: true
---

# backend/src/checkout/checkout-marketplace-pricing.util.ts

**Score**: 102.12765957446808 · **Tier**: 1 · **Phase**: 1 · **Effort**: 1.6h

## Top finding
- engine: knip
- rule: knip/unused-type
- line: 2
- message: "unused type: CheckoutMarketplacePaymentMethod"

## Why ranked here
- tier_weight: 4
- phase_priority: 8
- user_impact: 5
- effort_hours: 1.6

## Action items
- [ ] Investigate top finding
- [ ] Verify integration tests cover this path
- [ ] Mark `status: done` when fixed

## Links
- Source mirror: [[Kloel/99 - Espelho do Codigo/_source/backend/src/checkout/checkout-marketplace-pricing.util.ts]]
- Open in editor: `code backend/src/checkout/checkout-marketplace-pricing.util.ts`
