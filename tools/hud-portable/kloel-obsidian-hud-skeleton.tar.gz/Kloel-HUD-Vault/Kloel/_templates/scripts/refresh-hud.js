async function refreshHudIfStale(tp) {
  const fs = require('fs');
  const path = '__KLOEL_REPO_ROOT__/HUD_LAST_REFRESH.json';
  let stale = true;
  try {
    const stat = fs.statSync(path);
    const ageMs = Date.now() - stat.mtimeMs;
    stale = ageMs > 5 * 60 * 1000;
  } catch {
    /* file missing — definitely stale */
  }
  if (stale) {
    const { exec } = require('child_process');
    exec('node scripts/orchestration/hud-orchestrator.mjs --once > /tmp/hud-refresh.log 2>&1 &');
    return '_(HUD refresh kicked off in background — reopen note in 60s)_';
  }
  return '';
}
module.exports = refreshHudIfStale;
