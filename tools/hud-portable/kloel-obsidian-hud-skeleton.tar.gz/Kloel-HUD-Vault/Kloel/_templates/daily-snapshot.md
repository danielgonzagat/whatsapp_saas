---
date: <% tp.date.now("YYYY-MM-DD") %>
tags: [hud/snapshot]
auto_generated: true
generated_at: <% tp.date.now("YYYY-MM-DDTHH:mm:ssZ") %>
---

# Daily KLOEL Snapshot — <% tp.date.now("YYYY-MM-DD") %>

> Auto-captured at start of day. To refresh: `node scripts/orchestration/hud-orchestrator.mjs --once`.

## State at capture

- Last refresh: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
- Active branch: chore/ai-constitution-obsidian-graph-lock

## Top 3 blockers (linked to current 00-NEXT)

![[00-NEXT#Top 3 Blockers]]

## Phase progress

![[00-DAG#Phase progress]]

## Provider health

![[00-PROVIDERS#Status]]

## Notes
- 

## Tomorrow's plan
- 
