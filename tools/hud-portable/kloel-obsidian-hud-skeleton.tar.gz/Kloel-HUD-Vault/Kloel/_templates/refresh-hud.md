<%* await tp.user["refresh-hud"](tp) %>
